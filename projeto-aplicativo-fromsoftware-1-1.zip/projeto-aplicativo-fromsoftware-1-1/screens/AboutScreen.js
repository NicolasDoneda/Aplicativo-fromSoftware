import React from 'react';
import {View, Text, Image, ScrollView, StyleSheet, FlatList,} from 'react-native';
import { styles } from '../assets/css/stylesAbout';

export default function AboutScreen() {
  const evolucao = [
    {
      periodo: 'Anos 1980–1990: Origem e Consolidação',
      eventos: [
        '1986: Fundação da empresa como desenvolvedora de software corporativo.',
        '1994: Transição para os videogames com King’s Field.',
        'Final dos anos 90: Sucesso moderado com Armored Core, que virou franquia.',
      ],
    },
    {
      periodo: 'Anos 2000: Período de Transição',
      eventos: [
        'Jogos como Otogi, Lost Kingdoms e mais jogos da série Armored Core.',
        'Mantinha uma boa reputação, mas ainda era considerada uma empresa de nicho.',
      ],
    },
    {
      periodo: '2009: O Renascimento com Demon’s Souls',
      eventos: [
        'Sob a direção de Miyazaki, Demon’s Souls redefiniu a empresa.',
        'Inicialmente ignorado, virou cult no ocidente e vendeu bem.',
      ],
    },
    {
      periodo: '2011–2016: Era de Ouro dos Soulsborne',
      eventos: [
        'Dark Souls (2011) se torna um clássico instantâneo.',
        'Seguido por Dark Souls II, Bloodborne e Dark Souls III.',
        'O estilo "Soulslike" virou tendência na indústria.',
      ],
    },
    {
      periodo: '2019: Reconhecimento Mundial',
      eventos: [
        'Sekiro: Shadows Die Twice ganha Jogo do Ano no The Game Awards.',
        'Consolida a FromSoftware como uma referência mundial.',
      ],
    },
    {
      periodo: '2022: Elden Ring e Sucesso Global',
      eventos: [
        'Lançamento de Elden Ring, em parceria com George R. R. Martin.',
        'Mistura de mundo aberto, RPG clássico e combate desafiador.',
        'Se tornou o jogo mais vendido da empresa e aclamado pela crítica.',
      ],
    },
  ];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image
        source={require('../assets/Homeimages/logo.png')}
        style={styles.logo}
      />

      <Text style={styles.title}> FromSoftware </Text>

      <Text style={styles.text}>
        A FromSoftware foi fundada em novembro de 1986, no Japão, por Naotoshi
        Zin. Diferente do que muitos pensam, ela não começou fazendo jogos.
        Inicialmente, era uma empresa de desenvolvimento de software
        corporativo, voltado para o mercado de sistemas empresariais e
        ferramentas de produtividade para computadores. A sede era modesta, e a
        equipe pequena, mas a empresa já demonstrava interesse por inovação e
        tecnologia.
      </Text>

      <Text style={styles.text}>
        Com a popularização dos consoles de videogame nos anos 1990, a empresa
        viu uma oportunidade de entrar em um mercado em rápido crescimento. O
        PlayStation 1 estava prestes a ser lançado, e a FromSoftware decidiu
        apostar nesse novo cenário. Foi então que começou a transição para o
        desenvolvimento de jogos eletrônicos, um movimento arriscado, mas que
        mudaria o rumo da empresa para sempre.
      </Text>

      <Text style={styles.subtitle}> Primeiros Jogos </Text>

      <Image
        source={require('../assets/AboutImages/kingsfield.png')}
        style={styles.image}
      />

      <Text style={styles.text}>
        O primeiro grande sucesso da FromSoftware foi "King’s Field", lançado em
        1994 para o PlayStation 1. Era um RPG sombrio, em primeira pessoa, com
        ambientes misteriosos, monstros assustadores e uma dificuldade bastante
        elevada para a época. Diferente dos RPGs tradicionais, "King’s Field"
        colocava o jogador em um mundo obscuro e quase sem direção, forçando a
        exploração e o aprendizado por tentativa e erro. Esse estilo acabou se
        tornando uma das marcas registradas da empresa.
      </Text>

      <Text style={styles.text}>
        Apesar de ter sido lançado apenas no Japão, o jogo teve uma boa recepção
        e ganhou status cult. Isso motivou a FromSoftware a desenvolver
        sequências: King’s Field II, III e IV, que mantinham o mesmo estilo,
        cada vez mais refinado.
      </Text>

      <Image
        source={require('../assets/AboutImages/armoredcore.jpg')}
        style={styles.image}
      />

      <Text style={styles.text}>
        Pouco tempo depois, em 1997, a FromSoftware lançou "Armored Core", um
        jogo de ação focado em batalhas com mechas — robôs gigantes altamente
        customizáveis. A ideia era permitir que o jogador construísse e
        adaptasse seu próprio robô de combate, escolhendo armas, motores,
        pernas, braços e outros componentes. A jogabilidade combinava ação
        rápida com estratégia, e rapidamente o jogo conquistou fãs de ficção
        científica e combate tático.
      </Text>
      <Text style={styles.text}>
        O sucesso foi tanto que "Armored Core" se tornou uma das franquias mais
        longas da empresa, com dezenas de títulos e continuações lançados ao
        longo dos anos.
      </Text>

      <Image
        source={require('../assets/AboutImages/shadowtower.jpg')}
        style={styles.image}
      />

      <Text style={styles.text}>
        Além dos primeiros grandes sucessos como King’s Field e Armored Core, a
        FromSoftware também se aventurou em outros gêneros nos anos 1990 e
        início dos anos 2000, mostrando seu espírito experimental e criativo. Em
        1998, a empresa lançou Shadow Tower, considerado por muitos como um
        sucessor espiritual de King’s Field. O jogo seguia a mesma linha de RPG
        em primeira pessoa, mas com uma atmosfera ainda mais sombria, inimigos
        mais desafiadores e uma ambientação opressora, que exigia atenção
        constante do jogador.
      </Text>

      <Image
        source={require('../assets/AboutImages/echonight.png')}
        style={styles.image}
      />
      <Text style={styles.text}>
        No mesmo ano, foi lançado Echo Night, um título completamente diferente
        do que a empresa havia feito até então. Era um jogo de terror em
        primeira pessoa, com foco na narrativa, exploração e na atmosfera
        sobrenatural, em vez de combates intensos. Echo Night apresentava uma
        história envolvente sobre fantasmas e eventos misteriosos, oferecendo
        uma experiência mais contemplativa e emocional.
      </Text>

      <Text style={styles.subtitle}> Hidetaka Miyazaki </Text>

      <Text style={styles.text}>
        Hidetaka Miyazaki nasceu em 1974, na cidade de Shizuoka, no Japão.
        Cresceu em uma família simples e passou boa parte da infância lendo
        livros de fantasia, ficção científica e contos clássicos — influências
        que mais tarde moldariam seu estilo criativo. Durante a juventude, teve
        acesso limitado a jogos e literatura estrangeira, o que o levou a
        desenvolver o hábito de imaginar os detalhes das histórias que não
        conseguia entender completamente. Esse aspecto de interpretação pessoal
        aparece fortemente em seus jogos.
      </Text>

      <Text style={styles.text}>
        Formou-se em ciências sociais e trabalhou como contador por alguns anos.
        Somente aos 29 anos decidiu mudar de carreira, após jogar ICO, um título
        que o inspirou profundamente. Sem experiência prévia, entrou na
        FromSoftware como designer em 2004.
      </Text>

      <Text style={styles.text}>
        Sua grande virada veio com Demon’s Souls (2009), projeto que estava
        desacreditado até ele assumir a direção. O sucesso inesperado do jogo
        abriu as portas para a criação da série Dark Souls, onde Miyazaki ficou
        conhecido mundialmente por sua abordagem desafiadora, narrativa indireta
        e construção de mundos sombrios.
      </Text>

      <Text style={styles.text}>
        Em 2014, tornou-se presidente da FromSoftware, liderando projetos como
        Bloodborne, Sekiro e Elden Ring. Hoje, é considerado um dos mais
        influentes diretores e game designers da indústria de jogos.
      </Text>
      <Text style={styles.subtitle}> Evolução da Empresa </Text>

      <Text style={styles.text}>
        Com Dark Souls, a empresa ganhou respeito global. Em 2022, lançou Elden
        Ring, que se tornou Jogo do Ano.
      </Text>

      <FlatList
        data={evolucao}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.section}>
            <Text style={styles.periodo}>{item.periodo}</Text>
            {item.eventos.map((evento, idx) => (
              <View key={idx} style={styles.eventoItem}>
                <Text style={styles.bullet}>{'\u2022'}</Text>
                <Text style={styles.eventoTexto}>{evento}</Text>
              </View>
            ))}
          </View>
        )}
      />
    </ScrollView>
  );
}
