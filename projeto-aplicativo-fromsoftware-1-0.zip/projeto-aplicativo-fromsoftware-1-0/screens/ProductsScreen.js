import React from 'react';
import { View, Text, Image, FlatList, StyleSheet,ScrollView } from 'react-native';
// FlatList é otimizado para listas longas (renderiza apenas itens visíveis)
import Header from '../components/Header';

const products = [
  // Array de objetos com dados dos produtos
  {
    id: '1', // Chave única obrigatória
    name: "Demon's Souls",
    description: 'Preço: R$ 144,00 ',
    image: require('../assets/AboutImages/demonssoulsrem.jpg'),
    
  },
   {
    id: '2', // Chave única obrigatória
    name: "Dark Souls",
    description: 'Preço: R$ 144,00 ',
    image: require('../assets/productsImages/ds1Rem.jpg'),
    
  },
   {
    id: '3', // Chave única obrigatória
    name: "Dark Souls 2",
    description: 'Preço: R$ 144,00 ',
    image: require('../assets/Homeimages/ds2sotfs.jpg'),
    
  },
   {
    id: '4', // Chave única obrigatória
    name: "Bloodborne",
    description: 'Preço: R$ 220,00 ',
    image: require('../assets/productsImages/bb.jpg'),
    
  },
   {
    id: '5', // Chave única obrigatória
    name: "Dark Souls 3",
    description: 'Preço: R$ 220,00 ',
    image: require('../assets/Homeimages/imagensTimeLine/ds3.jpg'),
    
  },
   {
    id: '6', // Chave única obrigatória
    name: "Sekiro",
    description: 'Preço: R$ 220,00 ',
    image: require('../assets/productsImages/sekiro.png'),
    
  },
   {
    id: '7', // Chave única obrigatória
    name: "Elden Ring",
    description: 'Preço: R$ 250,00 ',
    image: require('../assets/productsImages/eldenring.jpg'),
    
  },
  // ... outros produtos
];

const ProductsScreen = () => {
  return (
    <ScrollView style={styles.container}>
       <View style={styles.logoContainer}>
        <Image
          source={require('../assets/Homeimages/logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>
      
      <FlatList
        data={products} // Fonte de dados
        keyExtractor={(item) => item.id} // Extrai chaves únicas
        renderItem={({ item }) => ( // Como renderizar cada item
          <View style={styles.productCard} >
            <Image source={item.image} style={styles.productImage } resizeMode = 'stretch'
            />
            <View style={styles.productInfo}>
              <Text style={styles.productName}>{item.name}</Text>
              <Text style={styles.productDescription}>{item.description}</Text>
            </View>
          </View>
        )}
        contentContainerStyle={styles.listContent} // Estilo da lista
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#18191a',
  },
  listContent: {
    padding: 20,
  },
  logoContainer: {
    marginTop: 40,
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  logo: {
    width: 230,
    height: 130,
  },
  productCard: {
    marginBottom: 20,
    borderRadius: 8,
    overflow: 'hidden',
    backgroundColor: '#39393b',
   
    elevation: 3,
  },
  productImage: {
    width: '100%',
    height: 150,
  },
  productInfo: {
    padding: 15,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#fff',
  },
  productDescription: {
    fontSize: 14,
    color: '#fff',
  },
});

export default ProductsScreen;