import React from 'react';
import { View, Text, Image, ScrollView, FlatList } from 'react-native';
import { styles } from '../assets/css/stylesHome'; // Importa os estilos de outro arquivo

export default function HomePage() {
  const gamesTimeLine = [
    {
      id: '1',
      title: "Demon's Souls",
      year: 2009,
      image: require('../assets/Homeimages/imagensTimeLine/dmsouls.jpg'),

    },
    {
      id: '2',
      title: 'Dark Souls',
      year: 2011,
      image: require('../assets/Homeimages/imagensTimeLine/ds1.png'),
    },
    {
      id: '3',
      title: 'Dark Souls 2',
      year: 2014,
      image: require('../assets/Homeimages/imagensTimeLine/ds2.jpg'),
    },
    {
      id: '4',
      title: 'Bloodborne',
      year: 2015,
      image: require('../assets/Homeimages/imagensTimeLine/bb.jpg'),
    },
    {
      id: '5',
      title: 'Dark Souls 3',
      year: 2016,
      image: require('../assets/Homeimages/imagensTimeLine/ds3.jpg'),
    },
    {
      id: '6',
      title: 'Sekiro',
      year: 2019,
      image: require('../assets/Homeimages/imagensTimeLine/sekiro.png'),
    },
    {
      id: '7',
      title: 'Elden Ring',
      year: 2022,
      image: require('../assets/Homeimages/imagensTimeLine/eldenring.jpg'),
    },
  ];

  const apresText = "FromSoftware é uma desenvolvedora japonesa de jogos eletrônicos, fundada em 1986 e sediada em Tóquio. A empresa é conhecida por criar títulos desafiadores e atmosferas imersivas, com destaque para franquias como Dark Souls, Bloodborne, Sekiro: Shadows Die Twice e Elden Ring. Sob a direção de Hidetaka Miyazaki, a FromSoftware ganhou reconhecimento mundial por seu estilo único de design, foco em narrativa ambiental e  jogabilidade exigente, influenciando profundamente a indústria dos  games.";

  const textoTimeLine ="Demons Souls (2009): O início da fórmula soulslike. Introduziu combate desafiador, morte punitiva e um mundo interconectado. Base para os jogos futuros. \n\nDark Souls (2011): Aperfeiçoou a fórmula com um mundo ainda maior, narrativa oculta e combate profundo. Definiu o gênero. \n\nDark Souls II (2014): Expansão da fórmula, mas com mecânicas e design divisivos. Ainda assim, uma boa base de fãs. \n\nBloodborne (2015): Focou no combate rápido e agressivo, com uma atmosfera gótica e inspirada em Lovecraft. Um dos mais aclamados pela crítica. \n\nDark Souls III (2016): A culminação da série. Combate polido, narrativa envolvente e design refinado. Um dos melhores jogos da geração. \n\nSekiro: Shadows Die Twice (2019): Mudou para um estilo mais focado em ação, com combate baseado em posturas e um mundo linear. Vencedor de Game of the Year. \n\nElden Ring (2022): O ápice da FromSoftware, combinando um mundo aberto com a fórmula soulslike. Aclamado como uma obra-prima."  
  

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Logo */}
      <View style={styles.logoContainer}>
        <Image
          source={require('../assets/Homeimages/logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      {/* Miyazaki */}
      <View style={styles.miyazakiContainer}>
        <Image
          source={require('../assets/Homeimages/miya.png')}
          style={styles.ceo}
          resizeMode="cover"
        />
      </View>

      {/* Texto de apresentação */}
      <Text style={styles.description} >

      {apresText}
        
      </Text>

      {/* Linha do Tempo */}
      <Text style={styles.timelineTitle}>Linha do Tempo dos Jogos</Text>
      
      <FlatList
        horizontal
        data={gamesTimeLine}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Image source={item.image} style={styles.image}
            resizeMode ='contain'
             />
            <Text style={styles.name}>{item.title}</Text>
            <Text style={styles.year}>{item.year}</Text>
          </View>
        )}
        showsHorizontalScrollIndicator={false}
      />
      
    <Text style = {styles.tituloTimeLine}>
        A Evolução dos Soulslikes da FromSoftware 
    </Text>
    <Text style={styles.description}>
        {textoTimeLine}
    </Text>
      
    </ScrollView>
  );
}
