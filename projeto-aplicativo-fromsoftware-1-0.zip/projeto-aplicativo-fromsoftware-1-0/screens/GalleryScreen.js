  import React,{useState} from 'react';
import { View, Text, Image, FlatList, StyleSheet,ScrollView, TouchableOpacity, Modal} from 'react-native';
import Header from '../components/Header';



const images = [
require('../assets/productsImages/ds1Rem.jpg'),
require('../assets/Homeimages/ds2sotfs.jpg'),
require('../assets/productsImages/eldenring.jpg'),
require('../assets/productsImages/sekiro.png'),
require('../assets/AboutImages/eldenringplay.jpg'),
require('../assets/AboutImages/gaelds3.jpg'),
require('../assets/AboutImages/gwynboss.jpg'),
require('../assets/AboutImages/haimeds2.jpg'),
// Adicione mais imagens conforme necessário
];

const GalleryScreen = () => {
return (
<ScrollView style={styles.container}>

<View style={styles.logoContainer}>  
    
    <Image  
      source={require('../assets/Homeimages/logo.png')}  
      style={styles.logo}  
      resizeMode="contain"  
    />  
    
  </View>  
    
  <Text style={styles.title}>Imagem dos jogos</Text>  
    <FlatList
        data={images}
        keyExtractor={(item, index) => index.toString()}
        numColumns={2}
        renderItem={({ item }) => (
          <Image source={item} style={styles.galleryImage} />
        )}
        contentContainerStyle={styles.galleryContainer}
      />
  
    
  

</ScrollView>

);
};

const styles = StyleSheet.create({
container: {
flex: 1,
backgroundColor: '#18191a',
},
logoContainer: {
marginTop: 40,
alignItems: 'center',
width: '100%',
marginBottom: 20,
},
logo: {
width: 230,
height: 130,
},
title: {
fontSize: 24,
fontWeight: 'bold',
textAlign: 'center',
marginVertical: 20,
color: '#fff',
},
galleryContainer: {
    padding: 10,
  },
galleryImage: {
    width: '48%',
    height: 150,
    margin: '1%',
    borderRadius: 8,
  },
});

export default GalleryScreen;