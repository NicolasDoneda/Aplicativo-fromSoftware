import React from 'react';
import { View, Text, StyleSheet, Linking, TouchableOpacity,Image,ScrollView } from 'react-native';
// Linking: para abrir URLs externas
// TouchableOpacity: botão que diminui opacidade quando pressionado
import { Ionicons } from '@expo/vector-icons'; // Ícones
import Header from '../components/Header';

const ContactScreen = () => {
  const handleEmailPress = () => {
    Linking.openURL('mailto:contato@marca.com.br'); // Abre cliente de email
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.logoContainer}>
        <Image
          source={require('../assets/Homeimages/logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>
      
      <View style={styles.content}>
        <Text style={styles.title}>Entre em Contato</Text>
        
        <TouchableOpacity 
          style={styles.contactItem} 
          onPress={handleEmailPress}   
        >
        {/* Botão clicável */}
          <Ionicons name="mail" size={24} color="#ffb60d" />
          <Text style={styles.contactText}>fromsoftware.jp</Text>
        </TouchableOpacity>
        
        {/* ... outros botões de contato */}
        
        
      </View>
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#18191a',
  },
  logoContainer: {
    marginTop: 40,
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  logo: {
    width: 230,
    height: 130,
    },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: 'white',
    textAlign: 'center',
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    padding: 15,
    backgroundColor: '#111112',
    borderRadius: 8,
  },
  contactText: {
    fontSize: 16,
    marginLeft: 15,
    color: '#fff',
  },
});


export default ContactScreen;