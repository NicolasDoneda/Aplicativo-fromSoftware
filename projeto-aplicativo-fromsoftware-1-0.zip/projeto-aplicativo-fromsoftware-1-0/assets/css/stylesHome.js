import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#18191a',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  logo: {
    width: 230,
    height: 130,
  },
  miyazakiContainer: {
    alignItems: 'center',
    width: '100%',
    marginBottom: 20,
  },
  ceo: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  description: {
    fontSize: 14,
    marginBottom: 30,
    color: '#fff',
    textAlign: 'justify',
  },
  timelineTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
  card: {
    marginRight: 12,
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 10,
    width: 150,
    alignItems: 'center',
    marginBottom: 30,
  },
  image: {
    width: 120,
    height: 70,
    borderRadius: 8,
  },
  name: {
    color: '#fff',
    fontWeight: 'bold',
    marginTop: 8,
    textAlign: 'center',
  },
  year: {
    color: '#aaa',
    fontSize: 12,
  },
  tituloTimeLine: {
  color:'white',
  fontSize: 18,
  fontFamily: 'Arial',
  fontWeight: 'bold',
  marginBottom: 10 ,

}
});
