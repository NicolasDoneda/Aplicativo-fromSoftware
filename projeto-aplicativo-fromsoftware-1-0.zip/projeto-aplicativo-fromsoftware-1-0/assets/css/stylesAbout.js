import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#18191a',
  },
  logo: {
    width: 200,
    height: 100,
    resizeMode: 'contain',
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 20,
    marginBottom: 10,
  },
  text: {
    color: '#ccc',
    fontSize: 16,
    textAlign: 'justify',
    marginBottom: 10,
  },
  image: {
    width: '60%',
    height: 200,
    marginVertical: 10,
    borderRadius: 12,
    marginBottom: 15,
  },
  section: {
  marginBottom: 20,
},
periodo: {
  fontSize: 18,
  fontWeight: 'bold',
  color: 'white',
  marginBottom: 5,
},
eventoItem: {
  flexDirection: 'row',
  alignItems: 'flex-start',
  marginBottom: 4,
},
bullet: {
  color: 'white',
  marginRight: 6,
  fontSize: 16,
},
eventoTexto: {
  color: '#ccc',
  fontSize: 15,
  flex: 1,
  textAlign: 'justify',
},


});